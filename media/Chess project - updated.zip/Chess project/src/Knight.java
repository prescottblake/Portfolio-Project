/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Knight extends the Piece superclass and implements a constructor
    and the checkForLegalMoves() method with knight specific logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/
public class Knight extends Piece
{
    public Knight (int rowLoc, int colLoc, String color)
    {
        super(rowLoc, colLoc, color);
        this.setName(color + " knight");
        checkForLegalMoves();
    }

    //checkForLegalMoves() overrides the method in Piece
    //Knight logic checks all legal knight moves
    //Knights ignore normal pathfinding rules and can skip over pieces
    @Override
    public void checkForLegalMoves()
    {
        BoardSquare currentSquare = this.getCurrentSquare();
        int currentRow = currentSquare.getRow();
        int currentCol = currentSquare.getColumn();
        BoardSquare targetSquare;
        int targetRow;
        int targetCol;

        this.legalMoves.clear();
        this.legalCaptures.clear();

        if (currentRow - 2 >= 0 && currentCol - 1 >= 0)
        {
            targetRow = currentRow - 2;
            targetCol = currentCol - 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow - 2 >= 0 && currentCol + 1 < 8)
        {
            targetRow = currentRow - 2;
            targetCol = currentCol + 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow + 2 < 8 && currentCol - 1 >= 0)
        {
            targetRow = currentRow + 2;
            targetCol = currentCol - 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow + 2 < 8 && currentCol + 1 >= 0)
        {
            targetRow = currentRow + 2;
            targetCol = currentCol + 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow - 1 >= 0 && currentCol - 2 >= 0)
        {
            targetRow = currentRow - 1;
            targetCol = currentCol - 2;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow - 1 >= 0 && currentCol + 2 < 8)
        {
            targetRow = currentRow - 1;
            targetCol = currentCol + 2;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow + 1 < 8 && currentCol - 2 >= 0)
        {
            targetRow = currentRow + 1;
            targetCol = currentCol - 2;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        if (currentRow + 1 < 8 && currentCol + 2 >= 0)
        {
            targetRow = currentRow + 1;
            targetCol = currentCol + 2;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }

    }
}
