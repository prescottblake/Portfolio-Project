/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Bishop extends the Piece superclass and implements a constructor
    and the checkForLegalMoves() method with bishop specific logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/
public class Bishop extends Piece
{
    public Bishop (int rowLoc, int colLoc, String color)
    {
        super(rowLoc, colLoc, color);
        this.setName(color + " bishop");
        checkForLegalMoves();
    }

    //checkForLegalMoves() overrides the method in Piece
    //Bishop logic checks the four diagonal paths
    @Override
    public void checkForLegalMoves()
    {
        BoardSquare currentSquare = this.getCurrentSquare();
        int currentRow = currentSquare.getRow();
        int currentCol = currentSquare.getColumn();
        BoardSquare targetSquare;
        int targetRow;
        int targetCol;
        boolean continuePath;

        this.legalMoves.clear();
        this.legalCaptures.clear();

        //diagonal up left
        targetRow = currentRow - 1;
        targetCol = currentCol - 1;

        while (targetRow >= 0 && targetCol >= 0)
        {
            continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
            if (!continuePath)
            {
                break;
            }
            targetRow -= 1;
            targetCol -= 1;
        }
        //diagonal up right
        targetRow = currentRow - 1;
        targetCol = currentCol + 1;

        while(targetRow >= 0 && targetCol < 8)
        {
            continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
            if (!continuePath)
            {
                break;
            }
            targetRow -= 1;
            targetCol += 1;
        }

        //diagonal down left
        targetRow = currentRow + 1;
        targetCol = currentCol - 1;

        while(targetRow < 8 && targetCol >= 0)
        {
            continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
            if (!continuePath)
            {
                break;
            }
            targetRow += 1;
            targetCol -= 1;
        }

        //diagonal down right
        targetRow = currentRow + 1;
        targetCol = currentCol + 1;

        while(targetRow < 8 && targetCol < 9)
        {
            continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
            if (!continuePath)
            {
                break;
            }
            targetRow += 1;
            targetCol += 1;
        }

    }
}
