/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Piece is a superclass intended to be extended by subclasses.
    Contains data and methods that are shared by all piece types,
    including movement logic and path checking logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/

import java.util.HashSet;
public class Piece
{
    private String name;
    private int rowLoc;
    private int colLoc;
    private final String COLOR;
    private BoardSquare currentSquare;
    protected HashSet<BoardSquare> legalMoves = new HashSet<BoardSquare>();
    protected HashSet<BoardSquare> legalCaptures = new HashSet<BoardSquare>();

    public Piece (int rowLoc, int colLoc, String color)
    {
        this.rowLoc = rowLoc;
        this.colLoc = colLoc;
        this.COLOR = color;
        this.currentSquare = Chessboard.getBoardSquare(rowLoc, colLoc);
    }

    //move() method handles movement and capture logic for all pieces
    //checks this piece's legalMoves and legalCaptures for the given
    //BoardSquare, and does comparison logic to confirm legality.
    //if move fails, no action is taken.
    public void move(BoardSquare targetSquare)
    {
        //capture logic
        if(legalCaptures.contains(targetSquare))
        {
            this.rowLoc = targetSquare.getRow();
            this.colLoc = targetSquare.getColumn();
            this.currentSquare.removeOccupyingPiece();
            this.currentSquare = targetSquare;
            this.checkForLegalMoves();

            String targetColor = targetSquare.getOccupyingPiece().getColor();

            if (targetColor.equals("black"))
            {
                Chessboard.blackPieces.remove(
                        targetSquare.getOccupyingPiece());
            }
            else if (targetColor.equals("white"))
            {
                Chessboard.whitePieces.remove(
                        targetSquare.getOccupyingPiece());
            }
            targetSquare.setOccupyingPiece(this);
        }
        //move logic
        else if (!legalMoves.contains(targetSquare))
        {
            System.out.println("Move is illegal");
        }
        else if (legalMoves.contains(targetSquare))
        {
            this.rowLoc = targetSquare.getRow();
            this.colLoc = targetSquare.getColumn();
            this.currentSquare.removeOccupyingPiece();
            this.currentSquare = targetSquare;
            this.checkForLegalMoves();
            targetSquare.setOccupyingPiece(this);

            System.out.println("Move is legal");
        }
        //calls for all pieces to update their legal moves
        Chessboard.updateLegalMoves();
    }

    //checkForLegalMoves() is intended to be overridden by
    //subclasses of the Piece class
    public void checkForLegalMoves()
    {
        this.legalMoves.clear();
    }

    //checkTargetSquare() method looks takes a piece's current square
    //and a target row and column.
    //Updates legalMoves and legalCaptures based on if the current
    //piece can move to or capture on the target BoardSquare.
    //returns boolean value of if whether the target square is
    //currently occupied.
    public boolean checkTargetSquare(
            BoardSquare currentSquare, int targetRow, int targetCol)
    {
        //sets canCapture string to opposite color as current square's
        //occupying piece
        String movingPieceColor = "";
        if (currentSquare.getOccupied())
        {
            movingPieceColor = currentSquare.getOccupyingPiece().getColor();
        }
        String canCapture = "";

        if (movingPieceColor.equals("white"))
        {
            canCapture = "black";
        }
        else if (movingPieceColor.equals("black"))
        {
            canCapture = "white";
        }

        if (targetRow >= 0 && targetRow < 8 && targetCol >= 0 && targetCol < 8)
        {
            BoardSquare targetSquare =
                    Chessboard.getBoardSquare(targetRow, targetCol);
            if (targetSquare.getOccupied())
            {
                if (targetSquare.getOccupyingPiece()
                        .getColor().equals(canCapture))
                {
                    this.legalCaptures.add(targetSquare);
                    return false;
                }
                else
                {
                    return false;
                }
            }
            else if (!targetSquare.getOccupied())
            {
                this.legalMoves.add(targetSquare);
                return true;
            }
        }
        return false;
    }

    public String getName()
    {
        return this.name;
    }

    public String getColor()
    {
        return this.COLOR;
    }
    public BoardSquare getCurrentSquare()
    {
        return this.currentSquare;
    }

    public HashSet<BoardSquare> getLegalMoves()
    {
        return this.legalMoves;
    }
    public HashSet<BoardSquare> getLegalCaptures()
    {
        return this.legalCaptures;
    }

    public void setName(String input)
    {
        this.name = input;
    }

    public void printLegalMoves()
    {
        System.out.println("Legal moves for the " + this.getName() + ":");
        for(BoardSquare currentSquare : legalMoves)
        {
            System.out.print(currentSquare.getName() + " ");
        }
        System.out.println();
    }

    public void printLegalCaptures()
    {
        System.out.println("Legal captures for the " + this.getName() + ":");
        for(BoardSquare currentSquare : legalCaptures)
        {
            System.out.print(currentSquare.getName() + " ");
        }
        System.out.println();
    }


}
