/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Pawn extends the Piece superclass and implements a constructor
    and the checkForLegalMoves() method with pawn specific logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/
public class Pawn extends Piece
{
    public Pawn (int rowLoc, int colLoc, String color)
    {
        super(rowLoc, colLoc, color);
        this.setName(color + " pawn");
        checkForLegalMoves();
    }

    //checkForLegalMoves() overrides the method in Piece
    //Pawn logic checks squares ahead for movement
    //checks 2 ahead for movement if pawn is on home row
    //checks diagonals for captures
    @Override
    public void checkForLegalMoves()
    {
        BoardSquare currentSquare = this.getCurrentSquare();
        int currentRow = currentSquare.getRow();
        int currentCol = currentSquare.getColumn();
        BoardSquare targetSquare;
        int targetRow;
        int targetCol;

        this.legalMoves.clear();
        this.legalCaptures.clear();

        //white pawn checks square ahead
        if (this.getColor().equals("white"))
        {
            targetRow = currentRow - 1;
            targetCol = currentCol;
            checkTargetSquare(currentSquare, targetRow, targetCol);

            if (currentRow == 6)
            {
                targetRow = currentRow - 2;
                targetCol = currentCol;
                checkTargetSquare(currentSquare, targetRow, targetCol);
            }
            if (Chessboard.getBoardSquare(
                    currentRow - 1, currentCol).getOccupied())
            {
                this.legalMoves.remove(
                        Chessboard.getBoardSquare(currentRow - 1, currentCol));
                this.legalCaptures.remove(
                        Chessboard.getBoardSquare(currentRow - 1, currentCol));
            }
            if(Chessboard.getBoardSquare(
                    currentRow - 2, currentCol).getOccupied())
            {
                this.legalMoves.remove(
                        Chessboard.getBoardSquare(currentRow - 2, currentCol));
                this.legalCaptures.remove(
                        Chessboard.getBoardSquare(currentRow - 2, currentCol));
            }

            //white pawn checks diagonals forward for captures
            targetRow = currentRow - 1;
            targetCol = currentCol - 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
            if (targetRow >= 0 && targetRow < 8
                    && targetCol >= 0 && targetCol < 8)
            {
                if (!Chessboard.getBoardSquare(
                        targetRow, targetCol).getOccupied())
                {
                    this.legalMoves.remove(
                            Chessboard.getBoardSquare(targetRow, targetCol));
                }
            }


            targetRow = currentRow - 1;
            targetCol = currentCol + 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
            if(targetRow >= 0 && targetRow < 8
                    && targetCol >= 0 && targetCol < 8)
            {
                if (!Chessboard.getBoardSquare(
                        targetRow, targetCol).getOccupied())
                {
                    this.legalMoves.remove(
                            Chessboard.getBoardSquare(targetRow, targetCol));
                }
            }
        }
        //black pawn checks square ahead
        else if (this.getColor().equals("black"))
        {
            targetRow = currentRow + 1;
            targetCol = currentCol;
            checkTargetSquare(currentSquare, targetRow, targetCol);

            if (currentRow == 1)
            {
                targetRow = currentRow + 2;
                targetCol = currentCol;
                checkTargetSquare(currentSquare, targetRow, targetCol);
            }
            if (Chessboard.getBoardSquare(
                    currentRow + 1, currentCol).getOccupied())
            {
                this.legalMoves.remove(
                        Chessboard.getBoardSquare(currentRow + 1, currentCol));
                this.legalCaptures.remove(
                        Chessboard.getBoardSquare(currentRow + 1, currentCol));
            }
            if (Chessboard.getBoardSquare(
                    currentRow + 2, currentCol).getOccupied())
            {
                this.legalMoves.remove(
                        Chessboard.getBoardSquare(currentRow + 2, currentCol));
                this.legalCaptures.remove(
                        Chessboard.getBoardSquare(currentRow + 2, currentCol));
            }

            //black pawn checks diagonals forward for captures
            targetRow = currentRow + 1;
            targetCol = currentCol - 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
            if (targetRow >= 0 && targetRow < 8
                    && targetCol >= 0 && targetCol < 8)
            {
                if (!Chessboard.getBoardSquare(
                        targetRow, targetCol).getOccupied())
                {
                    legalMoves.remove(
                            Chessboard.getBoardSquare(targetRow, targetCol));
                }
            }

            targetRow = currentRow + 1;
            targetCol = currentCol + 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
            if (targetRow >= 0 && targetRow < 8
                    && targetCol >= 0 && targetCol < 8)
            {
                if (!Chessboard.getBoardSquare(
                        targetRow, targetCol).getOccupied())
                {
                    legalMoves.remove(
                            Chessboard.getBoardSquare(targetRow, targetCol));
                }
            }
        }
    }
}
