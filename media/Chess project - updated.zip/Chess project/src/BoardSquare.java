/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    BoardSquare class allows for the creation of BoardSquare objects for
    use in the Chess program.
    BoardSquares populate the Chessboard created in the Chessboard class.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/

public class BoardSquare
{
    private String name = "";
    private final int ROW;
    private final int COLUMN;
    private boolean occupied = false;
    private Piece occupyingPiece;
    public BoardSquare(int row, int column)
    {
        this.ROW = row;
        this.COLUMN = column;
        this.name = Chessboard.convertCoordinatesToSquareName(row, column);
    }
    public String getName()
    {
        return this.name;
    }

    public int getRow()
    {
        return this.ROW;
    }
    public int getColumn()
    {
        return this.COLUMN;
    }
    public boolean getOccupied()
    {
        return this.occupied;
    }
    public Piece getOccupyingPiece()
    {
        return this.occupyingPiece;
    }
    public void setOccupyingPiece(Piece placedPiece)
    {
        this.occupied = true;
        this.occupyingPiece = placedPiece;
        Chessboard.occupiedSquares.put(this, placedPiece);
    }
    public void removeOccupyingPiece()
    {
        this.occupied = false;
        this.occupyingPiece = null;
        Chessboard.occupiedSquares.remove(this);
    }
}
