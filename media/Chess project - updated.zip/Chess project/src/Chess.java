/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Chess class houses the game loop and player/computer turns methods.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
    Tested to ensure user inputs are caught by try/catch block.
    Game cannot end itself, must be stopped manually.
*/

import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Chess
{
    public static void main(String[] args)
    {
        Scanner scnr = new Scanner(System.in);
        Chessboard board = new Chessboard();
        board.resetBoard();
        boolean gameFlag = true;
        boolean blackKingInCheck = false;
        boolean whiteKingInCheck = false;
        while (gameFlag)
        {
            //checkForCheck();
            playerTurn(scnr);
            //checkForCheck();
            computerTurn();
        }
    }

    //playerTurn method prompts player to select a piece to move
    //then to select a target boardsquare
    //and checks if that square is a legal move for the selected piece
    //while loop ensures that a legal move is taken before moving on.
    public static void playerTurn(Scanner scnr)
    {
        boolean playerTurn = true;
        while (playerTurn)
        {
            Chessboard.printBoard();
            Piece selectedPiece = selectPiece(scnr);
            selectedPiece.checkForLegalMoves();
            selectedPiece.printLegalMoves();
            selectedPiece.printLegalCaptures();
            BoardSquare targetSquare = selectTargetSquare(scnr, selectedPiece);

            if (selectedPiece.legalMoves.contains(targetSquare))
            {
                selectedPiece.move(targetSquare);
                playerTurn = false;
            }
            else if (selectedPiece.legalCaptures.contains(targetSquare))
            {
                selectedPiece.move(targetSquare);
                playerTurn = false;
            }
            else
            {
                System.out.println(selectedPiece.getName() +
                        " cannot move to " + targetSquare.getName());
            }
        }
    }

    //computerTurn() method handles logic for the computer's turn
    //prioritizes any available captures
    //if no captures are found, a random move is taken
    public static void computerTurn()
    {
        boolean foundViablePiece = false;
        Piece[] availablePieces = Chessboard.blackPieces.toArray(new Piece[0]);
        Random random = new Random();
        int randomNumber;
        Piece activePiece = availablePieces[0];

        for (Piece currentPiece : availablePieces)
        {
            if (!currentPiece.getLegalCaptures().isEmpty())
            {
                activePiece = currentPiece;
                foundViablePiece = true;
                System.out.println("Computer has identified a capture!");
            }
        }

        while (!foundViablePiece)
        {
            randomNumber = random.nextInt(Chessboard.blackPieces.size());
            activePiece = availablePieces[randomNumber];
            if (!activePiece.getLegalMoves().isEmpty())
            {
                foundViablePiece = true;
            }
            if (!activePiece.getLegalCaptures().isEmpty())
            {
                foundViablePiece = true;
            }
        }

        if (!activePiece.getLegalCaptures().isEmpty())
        {
            BoardSquare[] availableMoves =
                    activePiece.getLegalCaptures().toArray(new BoardSquare[0]);
            int randomIndex = random.nextInt(availableMoves.length);

            System.out.println("Computer moves " + activePiece.getName()
                    + " at " + activePiece.getCurrentSquare().getName()
                    + " to " + availableMoves[randomIndex].getName());

            activePiece.move(availableMoves[randomIndex]);
        }
        else if (!activePiece.getLegalMoves().isEmpty())
        {
            BoardSquare[] availableMoves =
                    activePiece.getLegalMoves().toArray(new BoardSquare[0]);
            int randomIndex = random.nextInt(availableMoves.length);

            System.out.println("Computer moves " + activePiece.getName()
                    + " at " + activePiece.getCurrentSquare().getName()
                    + " to " + availableMoves[randomIndex].getName());
            
            activePiece.move(availableMoves[randomIndex]);
        }
    }

    //selectPiece() method prompts player to select a piece
    //returns the selected piece if a valid coordinate is provided
    //otherwise, loops until valid piece is selected
    public static Piece selectPiece(Scanner scnr)
    {
        System.out.println("Please select a piece to move.");
        System.out.println("Use the format: a1");

        boolean needsInput = true;
        while(needsInput)
        {
            try
            {
                String userInput = scnr.next();

                for (int row = 0; row < Chessboard.board.size(); row++)
                {
                    for (int col = 0; col < Chessboard.board
                            .get(row).size(); col++)
                    {
                        if (Chessboard.board
                                .get(row).get(col).getName().equals(userInput)
                                && Chessboard.board
                                .get(row).get(col).getOccupied())
                        {
                            Piece selectedPiece = Chessboard.board
                                  .get(row).get(col).getOccupyingPiece();
                            needsInput = false;
                            System.out.println("You have selected the " +
                                  selectedPiece.getName()+ " at position " +
                                  selectedPiece.getCurrentSquare().getName());
                            return Chessboard.board.
                                    get(row).get(col).getOccupyingPiece();
                        } else if (Chessboard.board
                                .get(row).get(col).getName().equals(userInput)
                                && !Chessboard.board
                                .get(row).get(col).getOccupied())
                        {
                            System.out.println("There is no piece located at "
                                    + userInput);
                            break;
                        }
                    }
                }
                if (needsInput)
                {
                    System.out.println(
                            "Please enter a valid occupied board coordinate:");
                    System.out.println("Use the format: a1");
                }
            }
            catch (InputMismatchException excpt)
            {
                System.out.println("Please use the format: a1");
                needsInput = true;
            }
        }
        return null;
    }

    //selectTargetSquare() method prompts user to select
    // a BoardSquare by coordinate
    //checks BoardSquare at selected coordinate for occupying pieces
    //returns the selected BoardSquare if a valid coordinate is provided
    //otherwise, loops until valid BoardSquare is selected
    public static BoardSquare selectTargetSquare(
            Scanner scnr, Piece selectedPiece)
    {
        System.out.println("Please select a board square to move your "
                + selectedPiece.getName() + " to.");
        System.out.println("Use the format: a1");

        boolean needsInput = true;
        while (needsInput)
        {
            try
            {
                String userInput = scnr.next();

                for (int row = 0; row < Chessboard.board.size(); row++) {
                    for (int col = 0; col < Chessboard.board
                            .get(row).size(); col++) {
                        if(Chessboard.board.
                                get(row).get(col).getName().equals(userInput)
                                && Chessboard.board.
                                get(row).get(col).getOccupied())
                        {
                            BoardSquare selectedSquare = Chessboard.board.
                                    get(row).get(col);
                            needsInput = false;
                            System.out.println("You have selected the target: "
                                    + selectedSquare.getName());
                            System.out.println("It is currently occupied by: "
                                    + Chessboard.board.
                                    get(row).get(col).
                                    getOccupyingPiece().getName());
                            return Chessboard.board.get(row).get(col);
                        }
                        else if (Chessboard.board.
                                get(row).get(col).getName().equals(userInput)
                                && !Chessboard.board.
                                get(row).get(col).getOccupied())
                        {
                            BoardSquare selectedSquare = Chessboard.board.
                                    get(row).get(col);
                            needsInput = false;
                            System.out.println("You have selected the target: "
                                    + selectedSquare.getName());
                            System.out.println("There is no piece located at "
                                    + userInput);
                            return Chessboard.board.get(row).get(col);
                        }
                    }
                }
                if (needsInput)
                {
                    System.out.println(
                            "Please enter a valid board coordinate:");
                    System.out.println("Use the format: a1");
                }
            }
            catch (InputMismatchException excpt)
            {
                System.out.println("Please use the format: a1");
                needsInput = true;
            }
        }
        return null;
    }


    //checkForCheck() method is current unused
    //allows the game to check for if either king is in check
    public static void checkForCheck()
    {
        System.out.println("Checking for check!");
        King whiteKing = Chessboard.getWhiteKing();
        King blackKing = Chessboard.getBlackKing();
        HashSet<Piece> piecesPuttingWhiteInCheck = new HashSet<Piece>();
        HashSet<Piece> piecesPuttingBlackInCheck = new HashSet<Piece>();

        for (Piece currentPiece : Chessboard.blackPieces)
        {
            HashSet<BoardSquare> currentLegalCaptures =
                    currentPiece.getLegalCaptures();
            if (currentLegalCaptures.contains(whiteKing.getCurrentSquare()))
            {
                piecesPuttingWhiteInCheck.add(currentPiece);
            }
        }
        for (Piece currentPiece : Chessboard.whitePieces){
            HashSet<BoardSquare> currentLegalCaptures =
                    currentPiece.getLegalCaptures();
            if (currentLegalCaptures.contains(whiteKing.getCurrentSquare()))
            {
                piecesPuttingBlackInCheck.add(currentPiece);
            }
        }
        if (!piecesPuttingWhiteInCheck.isEmpty())
        {
            Chessboard.setWhiteKingInCheck(true);
        }
        if (!piecesPuttingBlackInCheck.isEmpty())
        {
            Chessboard.setWhiteKingInCheck(true);
        }

        if (Chessboard.getWhiteKingInCheck())
        {
            System.out.println("The white king is in check from: ");
            System.out.println(piecesPuttingWhiteInCheck.toString());
        }
        if (Chessboard.getBlackKingInCheck())
        {
            System.out.println("The black king is in check.");
            System.out.println(piecesPuttingBlackInCheck.toString());
        }
    }
}
