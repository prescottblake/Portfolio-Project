/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    King extends the Piece superclass and implements a constructor
    and the checkForLegalMoves() method with king specific logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/
public class King extends Piece
{
    public King (int rowLoc, int colLoc, String color)
    {
        super(rowLoc, colLoc, color);
        this.setName(color + " king");
        checkForLegalMoves();
    }

    //checkForLegalMoves() overrides the method in Piece
    //King logic checks all squares adjacent to the king
    @Override
    public void checkForLegalMoves()
    {
        BoardSquare currentSquare = this.getCurrentSquare();
        int currentRow = currentSquare.getRow();
        int currentCol = currentSquare.getColumn();
        BoardSquare targetSquare;
        int targetRow;
        int targetCol;
        boolean continuePath;

        this.legalMoves.clear();
        this.legalCaptures.clear();

        //horizontal left
        if(currentCol > 0)
        {
            targetRow = currentRow;
            targetCol = currentCol - 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        //horizontal right
        if(currentCol < 7)
        {
            targetRow = currentRow;
            targetCol = currentCol + 1;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        //vertical up
        if (currentRow < 7)
        {
            targetRow = currentRow + 1;
            targetCol = currentCol;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        //vertical down
        if (currentRow > 0)
        {
            targetRow = currentRow - 1;
            targetCol = currentCol;
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
        //diagonal up left
        targetRow = currentRow - 1;
        targetCol = currentCol - 1;
        if(targetRow >= 0 && targetCol >= 0)
        {
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }

        //diagonal up right
        targetRow = currentRow - 1;
        targetCol = currentCol + 1;
        if(targetRow >= 0 && targetCol < 8)
        {
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }

        //diagonal down left
        targetRow = currentRow + 1;
        targetCol = currentCol - 1;
        if(targetRow < 8 && targetCol >= 0)
        {
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }

        //diagonal down right
        targetRow = currentRow + 1;
        targetCol = currentCol + 1;
        if(targetRow < 8 && targetCol < 9)
        {
            checkTargetSquare(currentSquare, targetRow, targetCol);
        }
    }
}
