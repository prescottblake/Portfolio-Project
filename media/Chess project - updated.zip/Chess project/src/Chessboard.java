/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Chessboard class allows for the creation of Chessboard objects
    for use in the Chess program.
    Contains methods for creating the chessboard, populating boardsquares,
    creating pieces and converting array indexes to chess coordinates.
    Currently uses "magic numbers" to assign piece locations, sorry Mrs. Wyman!

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Chessboard
{
    protected static ArrayList<ArrayList<BoardSquare>> board =
            new ArrayList<ArrayList<BoardSquare>>();
    protected static HashMap<BoardSquare, Piece> occupiedSquares =
            new HashMap<BoardSquare, Piece>();
    protected static HashSet<Piece> whitePieces = new HashSet<>();
    protected static HashSet<Piece> blackPieces = new HashSet<>();

    private static King whiteKing;
    private static King blackKing;
    private static boolean whiteKingInCheck = false;
    private static boolean blackKingInCheck = false;

    public void resetBoard()
    {
        for (int i = 0; i < 8; i++)
        {
            ArrayList<BoardSquare> row = new ArrayList<BoardSquare>();
            for (int j = 0; j < 8; j++) {
                BoardSquare newSquare = new BoardSquare(i, j);
                row.add(newSquare);
            }
            board.add(row);
        }
        setPawns();
        setRooks();
        setKnights();
        setBishops();
        setQueens();
        setKings();
    }

    //updateLegalMoves() method causes each piece to
    //update their current legal moves
    public static void updateLegalMoves()
    {
        for (Piece currentPiece : blackPieces)
        {
            currentPiece.checkForLegalMoves();
        }
        for (Piece currentPiece : whitePieces)
        {
            currentPiece.checkForLegalMoves();
        }
    }

    //printBoard() method outputs the game to the console
    public static void printBoard()
    {
        System.out.println("  a   b   c  d   e  f   g   h");
        for (int row = 0; row < board.size(); row++)
        {
            System.out.print(8 - row + "|");
            for (int col = 0; col < board.get(row).size(); col++)
            {
                BoardSquare currentSquare = board.get(row).get(col);
                if (occupiedSquares.containsKey(currentSquare))
                {
                    System.out.printf("%-3s", convertPieceNameToUnicode
                            (currentSquare.getOccupyingPiece().getName()));
                }
                else
                {
                    System.out.printf("%-4s", " ");
                }
            }
            System.out.println();
        }
    }
    public void setPawns()
    {
        //set black pawns
        int row = 1;
        for (int col = 0; col < board.get(row).size(); col++)
        {
            Pawn newPawn = new Pawn(row, col, "black");
            board.get(row).get(col).setOccupyingPiece(newPawn);
            blackPieces.add(newPawn);
        }
        //set white pawns
        row = 6;
        for (int col = 0; col < board.get(row).size(); col++)
        {
            Pawn newPawn = new Pawn(row, col, "white");
            board.get(row).get(col).setOccupyingPiece(newPawn);
            whitePieces.add(newPawn);
        }
    }
    public void setRooks()
    {
        //create black rooks
        Rook newRook1 = new Rook(0, 0, "black");
        Rook newRook2 = new Rook(0, 7, "black");
        board.get(0).get(0).setOccupyingPiece(newRook1);
        blackPieces.add(newRook1);
        board.get(0).get(7).setOccupyingPiece(newRook2);
        blackPieces.add(newRook2);

        //create white rooks
        Rook newRook3 = new Rook(7, 0, "white");
        Rook newRook4 = new Rook(7, 7, "white");
        board.get(7).get(0).setOccupyingPiece(newRook3);
        whitePieces.add(newRook3);
        board.get(7).get(7).setOccupyingPiece(newRook4);
        whitePieces.add(newRook4);
    }
    public void setKnights()
    {
        //create black knights
        Knight newKnight1 = new Knight(0, 1, "black");
        Knight newKnight2 = new Knight(0, 6, "black");
        board.get(0).get(1).setOccupyingPiece(newKnight1);
        blackPieces.add(newKnight1);
        board.get(0).get(6).setOccupyingPiece(newKnight2);
        blackPieces.add(newKnight2);

        //create white knights
        Knight newKnight3 = new Knight(7, 1, "white");
        Knight newKnight4 = new Knight(7, 6, "white");
        board.get(7).get(1).setOccupyingPiece(newKnight3);
        whitePieces.add(newKnight3);
        board.get(7).get(6).setOccupyingPiece(newKnight4);
        whitePieces.add(newKnight4);
    }
    public void setBishops()
    {
        //create black bishops
        Bishop newBishop1 = new Bishop(0, 2, "black");
        Bishop newBishop2 = new Bishop(0, 5, "black");
        board.get(0).get(2).setOccupyingPiece(newBishop1);
        blackPieces.add(newBishop1);
        board.get(0).get(5).setOccupyingPiece(newBishop2);
        blackPieces.add(newBishop2);

        //create white bishops
        Bishop newBishop3 = new Bishop(7, 2, "white");
        Bishop newBishop4 = new Bishop(7, 5, "white");
        board.get(7).get(2).setOccupyingPiece(newBishop3);
        whitePieces.add(newBishop3);
        board.get(7).get(5).setOccupyingPiece(newBishop4);
        whitePieces.add(newBishop4);
    }
    public void setQueens()
    {
        //create black queen
        Queen newQueen1 = new Queen(0, 3, "black");
        //create white queen
        Queen newQueen2 = new Queen(7, 3, "white");
        board.get(0).get(3).setOccupyingPiece(newQueen1);
        blackPieces.add(newQueen1);
        board.get(7).get(3).setOccupyingPiece(newQueen2);
        whitePieces.add(newQueen2);
    }
    public void setKings()
    {
        //create black king
        King newKing1 = new King(0, 4, "black");
        blackKing = newKing1;
        //create white king
        King newKing2 = new King(7, 4, "white");
        whiteKing = newKing2;
        board.get(0).get(4).setOccupyingPiece(newKing1);
        blackPieces.add(newKing1);
        board.get(7).get(4).setOccupyingPiece(newKing2);
        whitePieces.add(newKing2);
    }


    public static BoardSquare getBoardSquare(int row, int column)
    {
        return board.get(row).get(column);
    }


    //convertCoordinatesToSquareName() method takes BoardSquare array positions
    //and returns chessboard coordinate names
    public static String convertCoordinatesToSquareName(int row, int column)
    {
        String name = "";
        if (column != -1) {
            switch (column) {
                case 0:
                    name += "a";
                    break;
                case 1:
                    name += "b";
                    break;
                case 2:
                    name += "c";
                    break;
                case 3:
                    name += "d";
                    break;
                case 4:
                    name += "e";
                    break;
                case 5:
                    name += "f";
                    break;
                case 6:
                    name += "g";
                    break;
                case 7:
                    name += "h";
                    break;
            }
        }
        if (row != -1) {
            switch (row) {
                case 0:
                    name += 8;
                    break;
                case 1:
                    name += 7;
                    break;
                case 2:
                    name += 6;
                    break;
                case 3:
                    name += 5;
                    break;
                case 4:
                    name += 4;
                    break;
                case 5:
                    name += 3;
                    break;
                case 6:
                    name += 2;
                    break;
                case 7:
                    name += 1;
                    break;
            }
        }
        return name;
    }
    //convertPieceNameToUnicode() method takes name strings from pieces
    //and returns unicode characters matching each chess piece
    public static String convertPieceNameToUnicode(String name)
    {
        String s = switch (name) {
            case "white pawn" -> "\u2659";
            case "black pawn" -> "\u265F";
            case "white rook" -> "\u2656";
            case "black rook" -> "\u265C";
            case "white bishop" -> "\u2657";
            case "black bishop" -> "\u265D";
            case "white knight" -> "\u2658";
            case "black knight" -> "\u265E";
            case "white queen" -> "\u2655";
            case "black queen" -> "\u265B";
            case "white king" -> "\u2654";
            case "black king" -> "\u265A";
            default -> "";
        };
        return s;
    }

    //following methods are related to check and checkmate logic
    //not implemented in this build
    public static King getBlackKing()
    {
        return blackKing;
    }
    public static King getWhiteKing()
    {
        return whiteKing;
    }
    public static boolean getWhiteKingInCheck()
    {
        return whiteKingInCheck;
    }
    public static boolean getBlackKingInCheck()
    {
        return blackKingInCheck;
    }
    public static void setWhiteKingInCheck(boolean check)
    {
        whiteKingInCheck = check;
    }
    public static void setBlackKingInCheck(boolean check)
    {
        blackKingInCheck = check;
    }


}
