/*
    Blake Prescott
    5/29/2024
    STEM Showcase Project: Chess
    Rook extends the Piece superclass and implements a constructor
    and the checkForLegalMoves() method with rook specific logic.

    TEST DATA:
    Ran program to confirm no exceptions or errors during runtime.
*/
public class Rook extends Piece
{
    public Rook (int rowLoc, int colLoc, String color)
    {
        super(rowLoc, colLoc, color);
        this.setName(color + " rook");
        checkForLegalMoves();
    }

    //checkForLegalMoves() overrides the method in Piece
    //Rook logic checks horizontal and vertical paths
    @Override
    public void checkForLegalMoves()
    {
        BoardSquare currentSquare = this.getCurrentSquare();
        int currentRow = currentSquare.getRow();
        int currentCol = currentSquare.getColumn();
        BoardSquare targetSquare;
        int targetRow;
        int targetCol;
        boolean continuePath;

        this.legalMoves.clear();
        this.legalCaptures.clear();

        //check all vertical and horizontal paths
        //once you encounter an obstacle, that path is over

        //horizontal left
        if (currentCol > 0)
        {
            continuePath = true;
            for (int column = currentCol - 1; column >= 0; column--)
            {
                targetRow = currentRow;
                targetCol = column;
                continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
                if (!continuePath)
                {
                    break;
                }
            }
        }
        //horizontal right
        if(currentCol < 7)
        {
            continuePath = true;
            for (int column = currentCol + 1; column < 8; column++)
            {
                targetRow = currentRow;
                targetCol = column;
                continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
                if (!continuePath)
                {
                    break;
                }
            }
        }

        //vertical up
        if (currentRow < 7)
        {
            continuePath = true;
            for (int row = currentRow + 1; row < 8; row++)
            {
                targetRow = row;
                targetCol = currentCol;
                continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
                if (!continuePath)
                {
                    break;
                }
            }
        }

        //vertical down
        if (currentRow > 0)
        {
            continuePath = true;
            for (int row = currentRow - 1; row >= 0; row--)
            {
                targetRow = row;
                targetCol = currentCol;
                continuePath = checkTargetSquare(currentSquare, targetRow, targetCol);
                if (!continuePath)
                {
                    break;
                }
            }
        }
    }
}
